package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Optional;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.SUCCESS;
import static com.ld.taskdemo.dbAdpter.TASK;
import static com.ld.taskdemo.dbAdpter.USER;

public class change_password extends AppCompatActivity {
    Context ctx;
    dbAdpter db;
    @BindView(R.id.txtcnfirmpassword) TextInputEditText txtcnfirmpassword;
    @BindView(R.id.txtnewpassword) TextInputEditText txtnewpassword;
    @BindView(R.id.txtoldpassword) TextInputEditText txtoldpassword;
    String userid,newpass,confpass,sql;
    Intent intent;

    @Optional
    @OnClick(R.id.btnchangepassword) void OnClick(View v) {
        userid = this.getIntent().getExtras().getString("uid");
        int ButtonId = v.getId();
        if (ButtonId == R.id.btnchangepassword) {
            if (ValidInput()==true){
                if(newpass.equals(confpass)) {
                    sql = "update " + USER + " set password='" + newpass + "',confirmpassword='" + confpass + "' where _id='" + userid + "'";
                    log.d("Edit=" + sql);
                    int result = db.RunQuery(sql);
                    if (result == SUCCESS) {
                        Toast.makeText(ctx, "New password Edit successfully", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(ctx, Login.class));
                        finish();
                    }
                }
                else{
                    Toast.makeText(ctx,"Error occur during the process",Toast.LENGTH_LONG).show();
                }
            }

        }

        }

    private boolean ValidInput() {
        boolean isValid = true;
        newpass = txtnewpassword.getText().toString().trim();
        confpass = txtcnfirmpassword.getText().toString().trim();
        if(newpass.length()==0)
        {
            txtnewpassword.setError("password required");
            isValid = false;
        }
        if(confpass.length()==0)
        {
            txtcnfirmpassword.setError("password required");
            isValid = false;
        }
        return isValid;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        getSupportActionBar().hide();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ButterKnife.bind(this);
        ctx = this;
        db = new dbAdpter(ctx,DATABASE,null,1);
       // GetExistingUserDetail();
    }

   // private void GetExistingUserDetail() {
      //  log.d(""+userid);
       // sql = "select * from '" + USER + "' where _id='" + userid + "'";
       // Cursor c = db.FetchRow(sql);
      //  if (c != null ) {
          //  txtoldpassword.setText(c.getString(c.getColumnIndex("password")));
          //  c.close();
       // }
   // }


}
