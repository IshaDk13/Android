package com.ld.taskdemo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.TASK;

public class Sadpter  extends RecyclerView.Adapter implements Filterable {
    private Context ctx;
    private  ArrayList<Task> TaskList;
    private ArrayList<Task> list;
    private String sql;
    private dbAdpter db;
    private SQLiteDatabase database;
    public Sadpter(Context ctx, ArrayList<Task> TaskList) {
        this.ctx = ctx;
        this.TaskList = TaskList;
        this.list=new ArrayList<>(TaskList);
        db = new dbAdpter(ctx,DATABASE,null,1);
        database = ctx.openOrCreateDatabase(DATABASE,SQLiteDatabase.OPEN_READWRITE,null);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View ExpenseRow = inflater.inflate(R.layout.task_row,null);
        TaskAdpter.MyWidgetContainer container = new TaskAdpter.MyWidgetContainer(ExpenseRow);
        return container;

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        TaskAdpter.MyWidgetContainer container = (TaskAdpter.MyWidgetContainer) holder; //to get reference of layout where you will display datq
        final Task e = TaskList.get(position); //to get get expense object to display it's data
        container.lbltitle.setText(e.getTitle());
        container.lblcategory.setText(e.getCategory());
        container.lblpriority.setText(e.getPriority());
        container.lblexpdate.setText(e.getTaskdate());
        container.lbltime.setText(e.getTime());
        Task CurrentTask = TaskList.get(position);

        container.btncopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String TextToCopy = "Task title = " + e.getTitle() + " Priority = " + e.getPriority() +
                        " Task Date = " + e.getTaskdate() + "Task Time=" + e.getTime();
                Storage.CopyToClipBoard(ctx, TextToCopy);
            }
        });
        container.btnshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String TextToCopy = "Task title = " + e.getTitle() + " Priority = " + e.getPriority() +
                        " Task Date = " + e.getTaskdate() + "Task time =" + e.getTime();
                Intent ImplicitIntent = new Intent();
                ImplicitIntent.putExtra(Intent.EXTRA_TEXT, TextToCopy);
                ImplicitIntent.putExtra(Intent.EXTRA_SUBJECT, "Share Task Detail");
                ImplicitIntent.setType("text/plain");
                ctx.startActivity(Intent.createChooser(ImplicitIntent, "Share Task Detail"));
            }
        });
        container.btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
                b1.setTitle("Confirm Task Complete?");
                b1.setIcon(R.drawable.done);
                b1.setMessage("are you sure you want to do this?");
                b1.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String[] whereArgs = {CurrentTask.getId()};
                        database.delete(TASK, "_id=?", whereArgs);
                        TaskList.remove(position);
                        notifyDataSetChanged();
                    }
                });
                b1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                b1.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return TaskList.size();
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter = new Filter() {
        int count=0;
    @Override
    protected FilterResults performFiltering(CharSequence charSequence) {
        ArrayList<Task> filteredList= new ArrayList<>();

        if(charSequence==null || charSequence.length()==0){
            filteredList.addAll(list);
        }
        else {
            String filterpattern = charSequence.toString().toLowerCase().trim();
            log.d("hello:"+filterpattern);
            for(Task item: list){
                if(item.getPriority().toLowerCase().contains(filterpattern)){
                    filteredList.add(item);
                    count++;
                }
            }
            log.d("count="+count);
            list=filteredList;
        }

        FilterResults results=new FilterResults();
        results.values=filteredList;
        log.d("result="+results.values);
        return results;
    }

    @Override
    protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
        TaskList.clear();
        TaskList.addAll((ArrayList<Task>) filterResults.values);
        notifyDataSetChanged();
    }
};

    private class MyWidgetContainer extends RecyclerView.ViewHolder{
        public TextView lbltitle,lblcategory,lblpriority,lblexpdate,lbltime;
        public ImageButton btncopy,btnshare,btnmenu,btndelete;
        public MyWidgetContainer(View itemview) {
            super(itemview);
            lbltitle = itemView.findViewById(R.id.lbltitle);
            lblcategory = itemView.findViewById(R.id.lblcategory);
            lblpriority = itemView.findViewById(R.id.lblpriority);
            lblexpdate = itemView.findViewById(R.id.lblexpdate);
            btncopy = itemView.findViewById(R.id.btncopy);
            btnshare = itemView.findViewById(R.id.btnshare);
            btnmenu = itemView.findViewById(R.id.btnmenu);
            btndelete=itemview.findViewById(R.id.btndelete);
            lbltime=itemview.findViewById(R.id.lbltime);

        }
    }



}
