package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnItemSelected;
import butterknife.Optional;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import static com.ld.taskdemo.dbAdpter.CATEGORY;
import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.PRIORITY;
import static com.ld.taskdemo.dbAdpter.SUCCESS;
import static com.ld.taskdemo.dbAdpter.TASK;

public class EditTask extends AppCompatActivity {

    Context ctx;
    dbAdpter db;

    @BindView(R.id.txttitle)
    TextInputEditText txttitle;
    @BindView(R.id.txtdetail) TextInputEditText txtdetail;
    @BindView(R.id.txttaskdate) TextInputEditText txttaskdate;
    @BindView(R.id.txttasktime) TextInputEditText txttasktime;
    @BindView(R.id.spncategorytitle)
    Spinner spncategorytitle;
    @BindView(R.id.spnprioritytitle) Spinner spnprioritytitle;
    String sql,title,detail,taskdate,tasktime,taskcat,taskpriority,taskdate2,SelectedCategory,SelectedPriority,taskid;

    @Optional
    @OnClick({R.id.btnsave,R.id.btnselectdate,R.id.btnselectime}) void OnClick(View v){
        int ButtonId=v.getId();
        if(ButtonId==R.id.btnselectdate)
        {
            int Year,Month,Day;
            GregorianCalendar gc1 = new GregorianCalendar();
            Year = gc1.get(Calendar.YEAR);
            Month = (gc1.get(Calendar.MONTH) +1);
            Day = gc1.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog dp1 = new DatePickerDialog(ctx, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                    txttaskdate.setText(day  + "/" + month + "/" + year);
                    taskdate2 = year + "/" + month + "/" + day; //store date in format that is required to manipulate date as date

                }
            },Year, Month, Day);

            dp1.show(); //it will display date picker dialog
        }
        else if(ButtonId==R.id.btnselectime)
        {

            int Hour,Minute;
            GregorianCalendar gc2 = new GregorianCalendar();
            Hour = gc2.get(Calendar.HOUR_OF_DAY);
            Minute = gc2.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    txttasktime.setText(hourOfDay + ":" + minute);
                }
            },Hour,Minute,false);
            timePickerDialog.show();//it will display date picker dialog
        }
        else if(ButtonId==R.id.btnsave){
            if (ValidInput()==true){
                sql = "update " + TASK + " set title='" + title + "',taskdate='" + taskdate + "',detail='" + detail +
                        "',time='" + tasktime + "',category='" + taskcat + "',priority='" + taskpriority +"' where _id=" + taskid;
                log.d("Edit="+sql);
                int result = db.RunQuery(sql);
                if (result == SUCCESS){
                    Toast.makeText(ctx,"Task Edit successfully",Toast.LENGTH_LONG).show();
                    startActivity(new Intent(ctx,Task_Container.class));
                    finish();
                }
                else{
                    Toast.makeText(ctx,"Error occur during the process",Toast.LENGTH_LONG).show();
                }
            }

        }

    }

    private boolean ValidInput() {
        boolean isValid = true;
        title = txttitle.getText().toString().trim();
        detail = txtdetail.getText().toString().trim();
        taskdate=txttaskdate.getText().toString();
        tasktime=txttasktime.getText().toString();
        taskpriority = spnprioritytitle.getSelectedItem().toString();
        taskcat = spncategorytitle.getSelectedItem().toString();
        if(title.length()==0)
        {
            txttitle.setError("title required");
            isValid = false;
        }

        if(detail.length()==0)
        {
            txtdetail.setError("detail is required");
            isValid = false;
        }
        if(taskdate.length()==0)
        {
            txttaskdate.setError("Date reqiured");
            isValid=false;
        }
        if(tasktime.length()==0)
        {
            txttasktime.setError("Time reqired");
            isValid=false;
        }
        return isValid;
    }
    @OnItemSelected(R.id.spncategorytitle)
    public void spinnerItemSelected(Spinner spncategorytitle, int position) {
        taskcat = spncategorytitle.getSelectedItem().toString();


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtask);
        ctx = this;
        db = new dbAdpter(ctx,DATABASE,null,1);
        ButterKnife.bind(this);
        FillCategory();
        FillPriority();
        GetExistingTaskDetail();
    }
    private void GetExistingTaskDetail() {
        taskid = this.getIntent().getExtras().getString("taskid");
        sql = "select * from " + TASK + " where _id=" + taskid;
        Cursor c = db.FetchRow(sql);
        if(c!=null && c.moveToNext()==true)
        {
            txttaskdate.setText(c.getString(c.getColumnIndex("taskdate")));
            txtdetail.setText(c.getString(c.getColumnIndex("detail")));
            txttitle.setText(c.getString(c.getColumnIndex("title")));
            txttasktime.setText(c.getString(c.getColumnIndex("time")));
            SelectedCategory = c.getString(c.getColumnIndex("category"));
            SelectedPriority=c.getString(c.getColumnIndex( "priority"));
            c.close();
        }
    }

    private void FillPriority() {
        String sql = "select title from " + PRIORITY + " order by title";
        Cursor c = db.FetchRow(sql);
        String title;
        ArrayList<String> PategoriesList = new ArrayList<>();
        int SelectedItemPosition=0,position=0;
        if(c!=null)
        {
            while(c.moveToNext()==true)
            {

                title = c.getString(c.getColumnIndex("title"));
                if(title.equals(SelectedCategory)==true)
                {
                    SelectedItemPosition = position;
                }
                PategoriesList.add(title);
                log.d("title = " + title);
                position++;
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx,
                    android.R.layout.simple_spinner_dropdown_item,PategoriesList);
            spnprioritytitle.setAdapter(adapter);
        }
    }

    private void FillCategory() {
        String sql = "select title from " + CATEGORY + " order by title";
        Cursor c = db.FetchRow(sql);
        String title;
        ArrayList<String> CategoriesList = new ArrayList<>();
        int SelectedItemPosition=0,position=0;
        if(c!=null)
        {
            while(c.moveToNext()==true)
            {

                title = c.getString(c.getColumnIndex("title"));
                if(title.equals(SelectedCategory)==true)
                {
                    SelectedItemPosition = position;
                }
                CategoriesList.add(title);
                log.d("title = " + title);
                position++;
            }
            c.close();
            ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx,
                    android.R.layout.simple_spinner_dropdown_item,CategoriesList);
            spncategorytitle.setAdapter(adapter);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = this.getMenuInflater();
        inflater.inflate(R.menu.mymenuoption,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int menuId=item.getItemId();
        if (menuId == R.id.mnucat) {
            Intent intent = new Intent(ctx,category.class);
            startActivity(intent);
            return true;
        }
        else{
            Toast.makeText(ctx,"errror",Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
