package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static com.ld.taskdemo.dbAdpter.CATEGORY;
import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.SUCCESS;

public class category extends AppCompatActivity {
    Context ctx;
    dbAdpter db;
    @BindView(R.id.addcat) EditText addcat;
    String title,sql;

    @OnClick(R.id.btnaddcat) void Onclick (View v){
        int Buttonid=v.getId();
        if(Buttonid==R.id.btnaddcat) {
            if (ValidInput() == true) {
                log.d("" + title);
                sql = "insert into " + CATEGORY + "(title) values " + "('" + title + "')";
                int result = db.RunQuery(sql);
                log.d("" + result);
                if (result == SUCCESS) {

                    addcat.setText("");
                    Toast.makeText(ctx, "category added successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ctx,Addtask.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(ctx, "Error error", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(ctx, "Error", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        ButterKnife.bind(this);
        ctx = this;
        db = new dbAdpter(ctx,DATABASE,null,0);

    }

    private boolean ValidInput() {
        boolean isValid = true;
        title = addcat.getText().toString().trim();

        if(title.length()==0)
        {
            addcat.setError("title required");
            isValid = false;
        }
        return isValid;
    }
}
