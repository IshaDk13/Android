package com.ld.taskdemo;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;

public class Storage {
    private Context ctx;
    private SharedPreferences preferences;
    private SharedPreferences.Editor DataWriter;

    private static final String FILENAME = "easylearn";
    public static final int INTEGER =1;
    public static final int STRING =2;
    public static final int FLOAT =3;
    public static final int BOOLEAN =4;
    public static final int LONG =5;
    public static final int DEFAULT_INTEGER_VALUE = 0;
    public static final float DEFAULT_FLOAT_VALUE = 0.0f;
    public static final String DEFAULT_STRING_VALUE = "";
    public static final Boolean DEFAULT_BOOLEAN_VALUE = false;
    public Object read(String key,int Datatype){
        Object temp = new Object();
        if(Datatype==INTEGER)
            temp = preferences.getInt(key,DEFAULT_INTEGER_VALUE);
        else if(Datatype==STRING)
            temp = preferences.getString(key,DEFAULT_STRING_VALUE);
        else if(Datatype==FLOAT)
            temp = preferences.getFloat(key,DEFAULT_FLOAT_VALUE);
        else if(Datatype==BOOLEAN)
            temp = preferences.getBoolean(key,DEFAULT_BOOLEAN_VALUE);
        else if(Datatype==LONG)
            temp = preferences.getLong(key,DEFAULT_INTEGER_VALUE);
        return  temp;
    }
    public Storage(Context ctx){
        this.ctx = ctx;
        preferences = ctx.getSharedPreferences(FILENAME,Context.MODE_PRIVATE);
        DataWriter = preferences.edit();
    }
    public void write(String key,String value){
        DataWriter.putString(key,value);
        DataWriter.commit();
    }
    public void write(String key,int value){
        DataWriter.putInt(key,value);
        DataWriter.commit();
    }
    public void write(String key,float value){
        DataWriter.putFloat(key,value);
        DataWriter.commit();
    }
    public void write(String key,boolean value){
        DataWriter.putBoolean(key,value);
        DataWriter.commit();
    }
    public void write(String key,long value){
        DataWriter.putLong(key,value);
        DataWriter.commit();
    }
    public void delete(String key){
        DataWriter.remove(key);
        DataWriter.apply(); //to confirm delete operation
    }
    public static void CopyToClipBoard(Context context, String TextToCopy){
        /* this method is used copy text into clipboard */
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Copied Text",TextToCopy);
        clipboard.setPrimaryClip(clip); //this will copy text into clipboard
    }
}
