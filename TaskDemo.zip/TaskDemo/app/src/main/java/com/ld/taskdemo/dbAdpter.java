package com.ld.taskdemo;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbAdpter extends SQLiteOpenHelper {
    private Context ctx;
    public static final String DATABASE="mytask.db";
    public static final String TASK="task";
    public static final String CATEGORY="categpry";
    public static final String PRIORITY="priority";
    public static final String USER="user";
    private static final String CREATE_TABLE_TASK="create table if not exists "+ TASK +
            "(_id INTEGER PRIMARY KEY AUTOINCREMENT , title text,taskdate text,detail text,time text,category text,priority text)";
    private static final String CREATE_TABLE_CATAGORY="create table if not exists "+ CATEGORY +
            "(_id INTEGER PRIMARY KEY AUTOINCREMENT,title text)";
    private static final  String CREATE_TABLE_USER="create table if not exists "+ USER +
            "(_id INTEGER PRIMARY KEY AUTOINCREMENT,email text ,password text,confirmpassword text,phone number)";
    private static final String CREATE_TABLE_PRIORITY="create table if not exists "+ PRIORITY +
            "(_id INTEGER PRIMARY KEY AUTOINCREMENT,title text)";
    public static final int VERSION=1;
    public static final int SUCCESS=1;
    public static final int ERROR=-1;
    private String[] Categories={"Work","TV","Shopping","Occation","Personal","Familial"};
    private String[] priorities={"HIGH","MEDIUM","LOW"};
    private String sql="";
    private SQLiteDatabase mydb;

    public dbAdpter(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context,DATABASE, null, VERSION);
        ctx=context;
        mydb = this.getWritableDatabase();
        Addcategories();
       AddPriorities();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_CATAGORY);
        sqLiteDatabase.execSQL(CREATE_TABLE_PRIORITY);
        sqLiteDatabase.execSQL(CREATE_TABLE_TASK);
        sqLiteDatabase.execSQL(CREATE_TABLE_USER);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) { }

    public int RunQuery(String sql){
        log.d(sql);
        try{
            mydb.execSQL(sql);
            log.d("record fetch");
        }
        catch (SQLException exception){
            log.e(exception.getMessage());
            return ERROR;
        }
        return SUCCESS;
    }


    private void AddPriorities() {
        sql="select _id from "+ PRIORITY;
        int count=GetRecordCount(sql);
        if(count==0)
        {
            int size=priorities.length;
            for(int i=0;i<size;i++){
                sql = "insert into " + PRIORITY  + " (title) values ('" + priorities[i] + "')";
                this.RunQuery(sql);
            }
        }
    }

    private void Addcategories() {
        sql="select _id from "+ CATEGORY;
        int count=GetRecordCount(sql);
        if(count==0)
        {
            int size=Categories.length;
            for(int i=0;i<size;i++){
                sql = "insert into " + CATEGORY  + " (title) values ('" + Categories[i] + "')";
                this.RunQuery(sql);
            }
        }
    }


    public Cursor FetchRow(String sql){
        Cursor c=null;
        try
        {
            c=mydb.rawQuery(sql,null);
            log.d("row query");
        }
        catch (SQLException e){
            e.getMessage();
        }
        return c;

    }


    public int GetRecordCount(String sql){
        Cursor c=FetchRow(sql);
        int count=0;
        if(c!=null){
            count=c.getCount();
            c.close();
        }
        return count;
    }

}
