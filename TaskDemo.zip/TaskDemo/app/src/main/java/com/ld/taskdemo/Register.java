package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.SUCCESS;
import static com.ld.taskdemo.dbAdpter.USER;

public class Register extends AppCompatActivity {
private Context ctx;
private dbAdpter db;
String sql,email,pass,cnfpass,phone;
@BindView(R.id.txtregisteremail) TextInputEditText txtregisteremail;
@BindView(R.id.txtregisterpassword) TextInputEditText txtregisterpassword;
@BindView(R.id.txtcnfpassword) TextInputEditText txtcnfpassword;
@BindView(R.id.txtphone) TextInputEditText txtphone;
@OnClick(R.id.btnregister) void OnClick(View v){
    int ButtonId=v.getId();
    if(ButtonId==R.id.btnregister)
    {
        if(validateInput()==true){
            if(pass.equals(cnfpass))
            {
            sql="insert into "+ USER + "(email,password,confirmpassword,phone) values "+
                    "('"+ email + "','"+ pass + "','"+ cnfpass +"','"+ phone + "')";
            log.d(""+sql);
            int result=db.RunQuery(sql);
            log.d(""+result);
            if(result==SUCCESS){

                    txtregisteremail.setText("");
                    txtregisterpassword.setText("");
                    txtcnfpassword.setText("");
                    txtphone.setText("");
                    Toast.makeText(ctx, "REGISTER SUCCESSFUL", Toast.LENGTH_LONG).show();
                    //Intent intent=new Intent(getApplicationContext(),Login.class);
                    //startActivity(intent);
                Intent intent=new Intent(this,Login.class);
                startActivity(intent);
                finish();
                }
            }
            else{
                Toast.makeText(ctx, "Error, please try after some time", Toast.LENGTH_LONG).show();}
        }

    }
}

    private boolean validateInput() {
        boolean isValid = true;
        email = txtregisteremail.getText().toString().trim();
        pass = txtregisterpassword.getText().toString().trim();
        cnfpass = txtcnfpassword.getText().toString().trim();
        phone = txtphone.getText().toString().trim();
        if (email.length() == 0) {
            txtregisteremail.setError("Email Required");
            isValid = false;
        }
        if (pass.length() == 0) {
            txtregisterpassword.setError("Password Reqired");
            isValid = false;
        }
        if (cnfpass.length() == 0)
        {
            txtcnfpassword.setError("Enter confirm password");
            isValid=false;
        }
        if(phone.length()==0){
            txtphone.setError("Please enter phone number");
            isValid=false;
        }

        return isValid;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        ButterKnife.bind(this);
        ctx=this;
        db=new dbAdpter(ctx,DATABASE,null,1);
    }
}
