package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Optional;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.ld.taskdemo.dbAdpter.CATEGORY;
import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.TASK;

public class Task_Container extends AppCompatActivity {
    Context ctx = this;
    ArrayList<Task> TaskList = new ArrayList<>();
    dbAdpter mydb;
    String sql="";
    String id,title,taskdate,category,time,priority,uid;
    Intent intent;

    @BindView(R.id.rectask) RecyclerView rectask;
//    @BindView(R.id.chkhigh) CheckBox chkhigh;
//    @BindView(R.id.chkmedium) CheckBox chkmedium;
//    @BindView(R.id.chklow) CheckBox chklow;


    CheckBox chkhigh;
    CheckBox chkmedium;
    CheckBox chklow;
    private Storage storage;


    @Optional
    @OnClick(R.id.btnaddtask) void OnClick(View v){
        startActivity(new Intent(ctx,Addtask.class));
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task__container);
        ButterKnife.bind(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        chkhigh = findViewById(R.id.chkhigh);
        chkmedium = findViewById(R.id.chkmedium);
        chklow = findViewById(R.id.chklow);
        storage = new Storage(ctx);
        mydb = new dbAdpter(ctx,DATABASE,null,1);
        uid = storage.read("userid",Storage.STRING).toString();
//       uid = this.getIntent().getExtras().getString("userid");
        sql = "select _id,title,taskdate,time,category,priority from '" + TASK + "' order by _id desc";
        GetDataFromSource();
        handleEvent();
        //super.onRestsuperart();
    }

    private void handleEvent() {
        CheckBoxListener listner = new CheckBoxListener();
        chkhigh.setOnCheckedChangeListener(listner);
        chkmedium.setOnCheckedChangeListener(listner);
        chklow.setOnCheckedChangeListener(listner);

    }


    private void GetDataFromSource() {

        Cursor c = mydb.FetchRow(sql);
        log.d(""+c);
        if(c!=null)
        {
            int TITLE = c.getColumnIndex("title");
            int ID = c.getColumnIndex("_id");
            int CATEGORY = c.getColumnIndex("category");
            int TIME = c.getColumnIndex("time");
            int PRIORITY=c.getColumnIndex("priority");
            int TASKDATE = c.getColumnIndex("taskdate");
            TaskList = new ArrayList<Task>();
            while(c.moveToNext())
            {
                title = c.getString(TITLE);
                category = c.getString(CATEGORY);
                priority=c.getString(PRIORITY);
                time = c.getString(TIME);
                taskdate = c.getString(TASKDATE);
                id = String.valueOf(c.getInt(ID));
                Task t= new Task(id,title,taskdate,time,category,priority);
                TaskList.add(t);
                log.d("hello");
            }
            TaskAdpter adapter = new TaskAdpter(ctx,TaskList);
            rectask.setLayoutManager(new GridLayoutManager(ctx,1));
            rectask.setItemAnimator(new DefaultItemAnimator());
            rectask.setAdapter(adapter);
            c.close();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = this.getMenuInflater();
        inflater.inflate(R.menu.mymenuoption,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int menuId=item.getItemId();
        if (menuId == R.id.mnulogout) {
            storage.delete("logged");
            intent = new Intent(ctx,Login.class);
            startActivity(intent);
            return true;
        }
        if (menuId == R.id.mnuchangepassword) {
            intent = new Intent(ctx,change_password.class).putExtra("uid",uid);
            startActivity(intent);
            return true;
        }
        else{
            Toast.makeText(ctx,"errror",Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    class CheckBoxListener implements CompoundButton.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            boolean high,medium,low;
            high = chkhigh.isChecked();
            medium = chkmedium.isChecked();
            low = chklow.isChecked();
            sql = "select _id,title,taskdate,time,category,priority from " + TASK + " where";
            if(high && medium && low)
            {
                log.d(""+sql);
                sql += " (priority='HIGH' or priority='MEDIUM' or priority='LOW')";
            }
            else if (high==true && low==true)
            {
                log.d(""+sql);
                sql += " (priority='HIGH' or priority='LOW')";
                log.d(""+sql);
            }
            else if (low==true && medium==true)
            {
                sql += " (priority='LOW' or priority='MEDIUM')";
            }
            else if (high==true && medium==true)
            {
                sql += " (priority='HIGH' or priority='MEDIUM')";
            }
            else if(high==true)
            {
                sql += " priority='HIGH'";
            }
            else if(low==true)
            {
                sql += " priority='LOW'";

            }
            else if(medium==true)
            {
                sql += " priority='MEDIUM'";
            }
            GetDataFromSource();
        }
    }
}
