package com.ld.taskdemo;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.USER;

public class Login extends AppCompatActivity {
private Context ctx;
private  dbAdpter db;
@BindView(R.id.txtemail) TextInputEditText txtemail;
@BindView(R.id.txtpassword) TextInputEditText txtpassword;
String email,password;
private Storage storage;
Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        getSupportActionBar().hide();//hide actionbar
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ButterKnife.bind(this);
        ctx = this;
        storage = new Storage(ctx);

        if(storage.read("logged",Storage.BOOLEAN).equals(true)){
            intent = new Intent(ctx,Task_Container.class);
            startActivity(intent);
        }
        else{

        }
        db = new dbAdpter(ctx,DATABASE,null,1);
       // setContentView(R.layout.activity_register);

    }
    @OnClick({R.id.btnlogin,R.id.lblregister}) void OnClick(View v){
        switch (v.getId()){
            case R.id.btnlogin:
                if (validateInput()){
                    String sql = "select * from '" + USER + "' where email='" + email + "' and password='" + password + "'";
                    Cursor cursor = db.FetchRow(sql);
                    if(cursor!=null && cursor.moveToNext()==true){
                        int uid = cursor.getColumnIndex("_id");
                        String userid = cursor.getString(uid);
                        log.d("uid="+userid);
                        storage.write("userid",userid);
                        storage.write("logged",true);
                        Toast.makeText(ctx,"Login successfully",Toast.LENGTH_LONG).show();
                        Intent intent=new Intent(getApplicationContext(),Task_Container.class).putExtra("userid",userid);
                        startActivity(intent);
                        finish();
                    }
                    else{
                        Toast.makeText(ctx,"Please enter valid email address and password :)",Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.lblregister:
                Intent intent=new Intent(getApplicationContext(),Register.class);
                startActivity(intent);
                break;
        }

    }

    private boolean validateInput() {
        boolean isValid = true;
        email = txtemail.getText().toString().trim();
        password = txtpassword.getText().toString().trim();

        if (email.length() == 0) {
            txtemail.setError("Email Required");
            isValid = false;
        }
        if (password.length() == 0) {
            txtpassword.setError("Password Reqired");
            isValid = false;
        }

        return isValid;
    }

}
