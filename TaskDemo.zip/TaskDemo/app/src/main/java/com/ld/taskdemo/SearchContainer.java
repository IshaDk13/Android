package com.ld.taskdemo;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;

import java.util.ArrayList;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Optional;

import static com.ld.taskdemo.dbAdpter.DATABASE;
import static com.ld.taskdemo.dbAdpter.TASK;

public class SearchContainer extends AppCompatActivity {
    Context ctx = this;
    ArrayList<Task> TaskList = new ArrayList<>();
    dbAdpter mydb;
    String sql, id, title, taskdate, category, time, priority;

    @BindView(R.id.rectask)
    RecyclerView rectask;

    @Optional
    @OnClick(R.id.btnaddtask)
    void OnClick(View v) {
        startActivity(new Intent(ctx, Addtask.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_container);
        ButterKnife.bind(this);
        mydb = new dbAdpter(ctx, DATABASE, null, 1);
        GetDataFromSource();
    }

    private void GetDataFromSource() {
        log.d("in getmethod");
        sql = "select _id,title,taskdate,time,category,priority from " + TASK + " order by _id desc";
        log.d("" + sql);
        Cursor c = mydb.FetchRow(sql);
        log.d("" + c);
        if (c != null && c.moveToNext() == true) {
            int TITLE = c.getColumnIndex("title");
            int ID = c.getColumnIndex("_id");
            int CATEGORY = c.getColumnIndex("category");
            int TIME = c.getColumnIndex("time");
            int PRIORITY = c.getColumnIndex("priority");
            int TASKDATE = c.getColumnIndex("taskdate");
            while (c.moveToNext()) {
                title = c.getString(TITLE);
                category = c.getString(CATEGORY);
                priority = c.getString(PRIORITY);
                time = c.getString(TIME);
                taskdate = c.getString(TASKDATE);
                id = String.valueOf(c.getInt(ID));
                Task t = new Task(id, title, taskdate, time, category, priority);
                TaskList.add(t);
                log.d("hello");
            }
            Sadpter adapter = new Sadpter(ctx, TaskList);
            rectask.setLayoutManager(new GridLayoutManager(ctx, 1));
            rectask.setItemAnimator(new DefaultItemAnimator());
            rectask.setAdapter(adapter);
            c.close();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        log.d("hello");
        MenuInflater inflater = this.getMenuInflater();
        inflater.inflate(R.menu.searchfilter, menu);

        MenuItem searchitem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchitem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                Sadpter adapter = new Sadpter(ctx,TaskList);
                adapter.getFilter().filter(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}
